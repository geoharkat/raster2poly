raster2poly
===========

Classify rasters and vectorise the result to clean, dissolved polygons.

.. code-block:: python

   from raster2poly import RasterClassifier

   clf = RasterClassifier("image.tif")
   gdf = clf.unsupervised(n_clusters=6)
   clf.save(gdf, "classes.gpkg")

.. toctree::
   :maxdepth: 2
   :caption: Contents

   quickstart
   api


Indices
-------

* :ref:`genindex`
* :ref:`modindex`
